import React from 'react';
function About(props){
    return (<>
        <h1>Name is {props.name}</h1>
        <h4>This is about page</h4>
    </>);
}
export default About;